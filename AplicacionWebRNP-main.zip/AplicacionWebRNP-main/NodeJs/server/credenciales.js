const connectionData = {
    user: "postgres",
    host: "localhost",
    database: "postgres",
    password: "proyecto",
    port: 2345,
};

module.exports = Object.freeze({
    connectionData
});