const express = require('express');
const app = express();
const cors = require('cors');
app.use(cors());
app.use(express.json());
app.use(express.json({ limit: '5mb', extended: true }));
const { Client } = require('pg')
const { connectionData } = require('./credenciales');
const port = 9090;

const client = new Client(connectionData)

client.connect(function (err) {
    if (err) {
        console.error('Database connection failed: ' + err.stack);
        return;
    }

    app.post('/registro_catedratico', (req, res) => {
        if ("name" in req.body) {
            client.query(
                `
                INSERT INTO Catedratico
                (nombre)
                VALUES('` + req.body.name + `')
                returning nombre;
                `
            ).then(response => {
                let name = response.rows[0] ? response.rows[0].nombre : null;
                res.json({ catedratico: name });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/registro_tema', (req, res) => {
        if ("name" in req.body) {
            client.query(
                `
                INSERT INTO Tema
                (nombre, temapadre)
                VALUES('`+ req.body.name + `', null)
                returning nombre;
                `
            ).then(response => {
                let name = response.rows[0] ? response.rows[0].nombre : null;
                res.json({ tema: name });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/registro_subtema', (req, res) => {
        if ("name" in req.body && "padre" in req.body) {
            client.query(
                `
                INSERT INTO Tema
                (nombre, temapadre)
                VALUES('`+ req.body.name + `', ` + req.body.padre + `)
                returning nombre;
                `
            ).then(response => {
                let name = response.rows[0] ? response.rows[0].nombre : null;
                res.json({ catedratico: name });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/registro_curso', (req, res) => {
        if ("name" in req.body) {
            client.query(
                `
                INSERT INTO Curso
                (nombre)
                VALUES('`+ req.body.name + `')
                returning nombre;
                `
            ).then(response => {
                let name = response.rows[0] ? response.rows[0].nombre : null;
                res.json({ catedratico: name });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/registro_ciclo', (req, res) => {
        if ("name" in req.body) {
            client.query(
                `
                INSERT INTO Ciclo
                (nombre)
                VALUES('`+ req.body.name + `')
                returning nombre;
                `
            ).then(response => {
                let name = response.rows[0] ? response.rows[0].nombre : null;
                res.json({ catedratico: name });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/registro_actividad', (req, res) => {
        if ("name" in req.body && "fecha" in req.body && "temas" in req.body) {
            client.query(
                `
                INSERT INTO Actividad
                (nombre, fecha)
                VALUES('`+ req.body.name + `', '` + req.body.fecha + `')
                returning id_actividad;
                `
            ).then(response => {
                let id_actividad = response.rows[0] ? response.rows[0].id_actividad : null;

                //construir la query
                let queryInsert = `
                    INSERT INTO Actividad_Tema
                    (id_actividad, id_tema)
                    VALUES`

                req.body.temas.forEach((val, key, arr) => {
                    queryInsert += arr.length - 1 === key ? "\n(" + id_actividad + ", " + val.id_tema + ");" : "\n(" + id_actividad + ", " + val.id_tema + "),";
                });

                client.query(queryInsert).then(response => {
                    res.json({ finish: response });
                })
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/asignar_curso', (req, res) => {
        if ("curso" in req.body && "catedratico" in req.body) {
            client.query(
                `
                INSERT INTO Curso_Catedratico
                (id_curso, id_catedratico)
                VALUES(`+ req.body.curso + `, ` + req.body.catedratico + `)
                returning 1 as asignado;
                `
            ).then(response => {
                let asignado = response.rows[0] ? response.rows[0].asignado : null;
                res.json({ asignado });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/asignar_actividad', (req, res) => {
        if ("actividad" in req.body && "curso" in req.body) {
            client.query(
                `
                INSERT INTO Actividad_Curso
                (id_actividad, id_curso)
                VALUES(`+ req.body.actividad + `, ` + req.body.curso + `)
                returning 1 as asignado;
                `
            ).then(response => {
                let asignado = response.rows[0] ? response.rows[0].asignado : null;
                res.json({ asignado });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/asignar_ciclo', (req, res) => {
        if ("ciclo" in req.body && "curso" in req.body) {
            client.query(
                `
                INSERT INTO Curso_Ciclo
                (id_curso, id_ciclo)
                VALUES(`+ req.body.curso + `, ` + req.body.ciclo + `)
                returning 1 as asignado;
                `
            ).then(response => {
                let asignado = response.rows[0] ? response.rows[0].asignado : null;
                res.json({ asignado });
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/obtener_proyectadas', (req, res) => {
        if ("mes" in req.body && "anio" in req.body && "curso" in req.body) {
            client.query(
                `
                select a.* from actividad a 
                inner join actividad_curso ac on a.id_actividad = ac.id_actividad 
                inner join curso c on c.id_curso = ac.id_curso
                where extract(month from a.fecha) = `+ req.body.mes +`
                and extract(year from a.fecha) = `+ req.body.anio +`
                and c.id_curso = `+ req.body.curso +`;
                `
            ).then(response => {
                res.json( response.rows );
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.post('/obtener_ejecutadas', (req, res) => {
        if ("mes" in req.body && "curso" in req.body) {
            client.query(
                `
                select a.* from actividad a 
                inner join actividad_curso ac on a.id_actividad = ac.id_actividad 
                inner join curso c on c.id_curso = ac.id_curso
                where a.fecha <= current_date
                and extract(month from a.fecha) = `+ req.body.mes +`
                and c.id_curso = `+ req.body.curso +`;
                `
            ).then(response => {
                res.json( response.rows );
            })
        } else {
            let succAnsw = { error: "request with incomplete data" };
            res.json(succAnsw);
        }
    })

    app.get('/obtener_temas', (req, res) => {
        client.query(
            `
                SELECT id_tema, nombre, temaPadre
                FROM Tema;
                `
        ).then(response => {
            res.json({ temas: response.rows });
        })
    })

    app.get('/obtener_cursos', (req, res) => {
        client.query(
            `
            SELECT id_curso, nombre
            FROM Curso;
            `
        ).then(response => {
            res.json({ cursos: response.rows });
        })
    })

    app.get('/obtener_ciclos', (req, res) => {
        client.query(
            `
            SELECT id_ciclo, nombre
            FROM Ciclo;
            `
        ).then(response => {
            res.json({ ciclos: response.rows });
        })
    })

    app.get('/obtener_catedraticos', (req, res) => {
        client.query(
            `
            SELECT id_catedratico, nombre
            FROM Catedratico;
            `
        ).then(response => {
            res.json({ catedraticos: response.rows });
        })
    })

    app.get('/obtener_actividades', (req, res) => {
        client.query(
            `
            SELECT id_actividad, nombre, fecha
            FROM Actividad;
            `
        ).then(response => {
            res.json({ actividades: response.rows });
        })
    })

});


app.listen(port, () => {
    console.log(`listening at http://localhost:${port}`)
})
