import React, { useState } from 'react';
import { withRouter, Link } from 'react-router-dom';
import Box from '@material-ui/core/Box';
import { Form, FormGroup } from 'reactstrap';
import TextField from '@material-ui/core/TextField';
import { makeStyles } from '@material-ui/core/styles';
import { Button } from "@rmwc/button";
import clsx from 'clsx';
import axios from 'axios';
import serversAddr from '../serversAddr';
import 'date-fns';
import '@rmwc/typography/styles';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const useStyles = makeStyles((theme) => ({
    margin: {
        margin: theme.spacing(1),
        width: '100%',
        justifyContent: 'center'
    },
    textField: {
        width: '35ch',
        backgroundColor: "#FFFFFF",
    },
    centrarContenido: {
        textAlign: 'center',
    },

}));

const Curso = () => {
    const classes = useStyles();
    const [valuesUser, setValues] = useState({
        curso: ''
    });
    const imagenPerfil = '/actividad.png';

    const handleChange = (prop) => (event) => {
        setValues({ ...valuesUser, [prop]: event.target.value });
    };

    const handleClick = async (event) => {
        event.preventDefault()

        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/registro_curso', { name: valuesUser.curso })
            .then(response => {
                if (response.status === 200) {
                    toast.success("Curso Registrado! " + response.data.catedratico, { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    setValues({curso: ''})
                } else {
                    toast.error("No se ha podido registrar el Curso", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    return (
        <div>
            <div align="center">
                <img style={{height: "20%", width: "20%"}} align="center" alt="imagen ususario iniciar sesión" src={imagenPerfil} />
                <h3>Curso</h3>
            </div>
            <Box display="flex" justifyContent="center" >
                <Form onSubmit={handleClick}>
                    <FormGroup>
                        <Box>
                            <TextField
                                label="Nombre de Curso"
                                onChange={handleChange('curso')}
                                required
                                id="outlined-required"
                                className={clsx(classes.margin, classes.textField)}
                                value={valuesUser.curso}
                                variant="outlined"
                            />
                        </Box>
                        <div className={classes.centrarContenido}>

                            <Button
                                variant="contained"
                                size="large"
                                style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '95%', justifyContent: 'center', alignItems: 'center' }}
                            >
                                Registrar
                            </Button>
                        </div>
                    </FormGroup>
                </Form>
            </Box>
        </div>
    );
}

export default withRouter(Curso);
