import React from "react";
import './Inicio.css';
import 'react-toastify/dist/ReactToastify.css';

const Inicio = () => {
    return (
        <div className='App'>
        </div>
    );
};

export default Inicio;