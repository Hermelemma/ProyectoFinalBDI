import React, { useState, useEffect } from 'react';
import { withRouter } from 'react-router-dom';
import Box from '@material-ui/core/Box';
import { Form, FormGroup } from 'reactstrap';
import TextField from '@material-ui/core/TextField';
import { Button } from "@rmwc/button";
import axios from 'axios';
import serversAddr from '../serversAddr';
import { toast } from 'react-toastify';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Dropdown } from 'primereact/dropdown';
import DatePicker from "react-datepicker";
import { PickList } from 'primereact/picklist';
import 'date-fns';
import '@rmwc/typography/styles';
import 'react-toastify/dist/ReactToastify.css';
import "react-datepicker/dist/react-datepicker.css";

const Actividad = () => {
    const [tema, setTema] = useState({
        name: ''
    });

    const [subTema, setSubTema] = useState({
        name: '',
        padre: ''
    });

    const [actividad, setActividad] = useState({
        name: '',
        padre: ''
    });

    const [temas, setTemas] = useState([])
    const [temaSeleccionado, setTemaSeleccionado] = useState(null);
    const [refresh, setRefresh] = useState(true);
    const [startDate, setStartDate] = useState(new Date());
    const [temasActividad, setTemasActividad] = useState([]);
    const [temasAdd, setTemasAdd] = useState([]);

    useEffect(() => {
        setRefresh(false);
        //cargar Temas
        async function obtenerTemas() {
            await axios.get('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_temas')
                .then(response => {
                    if (response.status === 200) {
                        setTemas(response.data.temas);
                        setTemasAdd(response.data.temas);
                        setTemasActividad([]);
                    } else {
                        toast.error("No se puedieron obtener los temas registrados.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    }
                })
        }
        obtenerTemas();
    }, [refresh]);

    const onChange = (event) => {
        setTemasAdd(event.source);
        setTemasActividad(event.target);
    }

    const handleChangeTema = (prop) => (event) => {
        setTema({ ...tema, [prop]: event.target.value });
    };

    const handleChangeSubTema = (prop) => (event) => {
        setSubTema({ ...subTema, [prop]: event.target.value });
    };

    const handleChangeActividad = (prop) => (event) => {
        setActividad({ ...actividad, [prop]: event.target.value });
    };

    const onChangeTema = (e) => {
        setTemaSeleccionado(e.value);
        setSubTema({
            padre: e.value.id_tema
        });
    }
    
    const handleClickTema = async (event) => {
        event.preventDefault()

        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/registro_tema', { name: tema.name })
            .then(response => {
                if (response.status === 200) {
                    toast.success("Tema Registrado! " + response.data.tema, { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    setTema({ name: '' })
                    setRefresh(true);
                } else {
                    toast.error("No se ha podido registrar el Tema", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    const handleClickSubTema = async (event) => {
        event.preventDefault()

        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/registro_subtema',
            {
                name: subTema.name,
                padre: subTema.padre
            })
            .then(response => {
                if (response.status === 200) {
                    toast.success("Catedratico Registrado! " + response.data.catedratico, { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    setSubTema({
                        name: '',
                        padre: ''
                    });
                    setTemaSeleccionado(undefined);
                    setRefresh(true);
                } else {
                    toast.error("No se ha podido registrar el Catedratico", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    const handleClickActividad = async (event) => {
        event.preventDefault()

        if (temasActividad.length < 1) {
            toast.warn("Es necesario agregar por lo menos un tema", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
            return
        }
        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/registro_actividad', { name: actividad.name, fecha: startDate, temas: temasActividad })
            .then(response => {
                if (response.status === 200) {
                    toast.success("Tema Registrado! " + response.data.tema, { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    setActividad({ name: '' })
                    setRefresh(true);
                    setTemasActividad([]);
                } else {
                    toast.error("No se ha podido registrar el Tema", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    const itemTemplate = (item) => {
        return (
            <div className="product-item">
                <h6 className="mb-2">{item.nombre}</h6>
            </div>
        );
    }

    return (
        <div style={{ width: "80%", marginLeft: "10%" }}>
            <Accordion className="accordion-custom" activeIndex={2}>
                <AccordionTab header={<React.Fragment><span>Tema</span></React.Fragment>}>
                    <Box display="flex" justifyContent="center" >
                        <Form onSubmit={handleClickTema} style={{ width: "90%" }}>
                            <FormGroup>
                                <TextField
                                    label="Nombre de Tema"
                                    onChange={handleChangeTema('name')}
                                    required
                                    id="outlined-required"
                                    value={tema.name}
                                    variant="outlined"
                                    style={{ width: "100%" }}
                                />
                                <Button
                                    variant="contained"
                                    size="large"
                                    style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '100%', justifyContent: 'center', alignItems: 'center' }}
                                >
                                    Registrar
                                </Button>
                            </FormGroup>
                        </Form>
                    </Box>
                </AccordionTab>
                <AccordionTab header={<React.Fragment><span>Subtema</span></React.Fragment>}>
                    <Box display="flex" justifyContent="center" >
                        <Form onSubmit={handleClickSubTema} style={{ width: "90%" }}>
                            <FormGroup>
                                <Dropdown
                                    value={temaSeleccionado}
                                    options={temas}
                                    onChange={onChangeTema}
                                    optionLabel="nombre"
                                    filter
                                    showClear
                                    filterBy="nombre"
                                    placeholder="Seleccione un Tema"
                                    style={{ width: "100%" }}
                                    required
                                />
                                <TextField
                                    label="Nombre de SubTema"
                                    onChange={handleChangeSubTema('name')}
                                    required
                                    id="outlined-required"
                                    value={subTema.name}
                                    variant="outlined"
                                    style={{ width: "100%" }}
                                />
                                <Button
                                    variant="contained"
                                    size="large"
                                    style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '100%', justifyContent: 'center', alignItems: 'center' }}
                                >
                                    Registrar
                                </Button>
                            </FormGroup>
                        </Form>
                    </Box>
                </AccordionTab>
                <AccordionTab header={<React.Fragment><span>Actividad</span></React.Fragment>}>
                    <Box display="flex" justifyContent="center" >
                        <Form onSubmit={handleClickActividad} style={{ width: "90%" }}>
                            <FormGroup>
                                <h5>Al seleccionar un tema del siguiente listado, se agrega a la actividad.</h5>
                                <PickList
                                    source={temasAdd}
                                    target={temasActividad}
                                    sourceHeader="Disponibles"
                                    targetHeader="Seleccionados"
                                    sourceStyle={{ height: '342px' }}
                                    targetStyle={{ height: '342px' }}
                                    onChange={onChange}
                                    filterBy="name" s
                                    sourceFilterPlaceholder="Nombre"
                                    targetFilterPlaceholder="Nombre"
                                    itemTemplate={itemTemplate}
                                />
                                <TextField
                                    label="Nombre de Actividad"
                                    onChange={handleChangeActividad('name')}
                                    required
                                    id="outlined-required"
                                    value={actividad.name}
                                    variant="outlined"
                                    style={{ width: "100%" }}
                                />
                                <DatePicker
                                    selected={startDate}
                                    onChange={(date) => setStartDate(date)}
                                    dateFormat="dd/MM/yyyy"
                                />
                                <Button
                                    variant="contained"
                                    size="large"
                                    style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '100%', justifyContent: 'center', alignItems: 'center' }}
                                >
                                    Registrar
                                </Button>
                            </FormGroup>
                        </Form>
                    </Box>
                </AccordionTab>
            </Accordion>
        </div>
    );
}

export default withRouter(Actividad);
