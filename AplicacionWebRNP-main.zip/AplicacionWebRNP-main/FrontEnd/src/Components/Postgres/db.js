import postgres from 'postgres'

const sql = postgres('postgres://username:password@host:port/database', {
    host                 : 'localhost',            // Postgres ip address[s] or domain name[s]
    port                 : 2345,          // Postgres server port[s]
    database             : 'postgres',            // Name of database to connect to
    username             : 'postgres',            // Username of database user
    password             : 'proyecto',            // Password of database user
  });

export default sql