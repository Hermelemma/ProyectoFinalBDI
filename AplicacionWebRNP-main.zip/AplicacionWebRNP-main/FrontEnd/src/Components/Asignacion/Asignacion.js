import React, { useState, useEffect } from 'react';
import { withRouter } from 'react-router-dom';
import Box from '@material-ui/core/Box';
import { Form, FormGroup } from 'reactstrap';
import { Button } from "@rmwc/button";
import axios from 'axios';
import serversAddr from '../serversAddr';
import { toast } from 'react-toastify';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Dropdown } from 'primereact/dropdown';
import 'date-fns';
import '@rmwc/typography/styles';
import 'react-toastify/dist/ReactToastify.css';
import "react-datepicker/dist/react-datepicker.css";

const Asignacion = () => {

    const [selecciones, setSelecciones] = useState({
        cursoSeleccionado1: undefined,
        cursoSeleccionado2: undefined,
        cursoSeleccionado3: undefined,
        catedraticoSeleccionado: undefined,
        cicloSeleccionado: undefined,
        actividadSeleccionada: undefined
    });

    const [cursos, setCursos] = useState([])
    const [catedraticos, setCatedraticos] = useState([])
    const [ciclos, setCiclos] = useState([])
    const [actividades, setActividades] = useState([])
    const [refresh, setRefresh] = useState(true);

    useEffect(() => {
        setRefresh(false);
        //cargar Temas
        async function obtenerCursos() {
            await axios.get('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_cursos')
                .then(response => {
                    if (response.status === 200) {
                        setCursos(response.data.cursos);
                    } else {
                        toast.error("No se puedieron obtener los cursos registrados.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    }
                })
        }
        async function obtenerActividades() {
            await axios.get('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_actividades')
                .then(response => {
                    if (response.status === 200) {
                        setActividades(response.data.actividades);
                    } else {
                        toast.error("No se puedieron obtener las actividades registradas.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    }
                })
        }
        async function obtenerCatedraticos() {
            await axios.get('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_catedraticos')
                .then(response => {
                    if (response.status === 200) {
                        setCatedraticos(response.data.catedraticos);
                    } else {
                        toast.error("No se puedieron obtener los catedraticos registrados.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    }
                })
        }
        async function obtenerCiclos() {
            await axios.get('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_ciclos')
                .then(response => {
                    if (response.status === 200) {
                        setCiclos(response.data.ciclos);
                    } else {
                        toast.error("No se puedieron obtener los temas registrados.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    }
                })
        }
        obtenerCursos();
        obtenerActividades();
        obtenerCatedraticos();
        obtenerCiclos();
    }, [refresh]);

    const onChangeCurso1 = (e) => {
        setSelecciones({
            ...selecciones, cursoSeleccionado1: e.value
        });
    }

    const onChangeCurso2 = (e) => {
        setSelecciones({
            ...selecciones, cursoSeleccionado2: e.value
        });
    }

    const onChangeCurso3 = (e) => {
        setSelecciones({
            ...selecciones, cursoSeleccionado3: e.value
        });
    }

    const onChangeActividad = (e) => {
        setSelecciones({
            ...selecciones, actividadSeleccionada: e.value
        });
    }

    const onChangeCatedratico = (e) => {
        setSelecciones({
            ...selecciones, catedraticoSeleccionado: e.value
        });
    }

    const onChangeCiclo = (e) => {
        setSelecciones({
            ...selecciones, cicloSeleccionado: e.value
        });
    }

    const handleClickCatedratico = async (event) => {
        event.preventDefault()

        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/asignar_curso', {
            curso: selecciones.cursoSeleccionado1.id_curso,
            catedratico: selecciones.catedraticoSeleccionado.id_catedratico
        })
            .then(response => {
                if (response.status === 200) {
                    toast.success("Se asigno el catedratico al curso! " + response.data.asignado, { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    setSelecciones({
                        ...selecciones,
                        cursoSeleccionado1: undefined,
                        catedraticoSeleccionado: undefined
                    });
                } else {
                    toast.error("No se ha podido asignar el catedratico al curso", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    const handleClickActividad = async (event) => {
        event.preventDefault()

        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/asignar_actividad',
            {
                actividad: selecciones.actividadSeleccionada.id_actividad,
                curso: selecciones.cursoSeleccionado2.id_curso
            })
            .then(response => {
                if (response.status === 200) {
                    toast.success("Se asigno la actividad al curso! " + response.data.asignado, { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    setSelecciones({
                        ...selecciones,
                        cursoSeleccionado2: undefined,
                        actividadSeleccionada: undefined
                    });
                } else {
                    toast.error("No se ha podido asignar la actividad al curso", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    const handleClickCiclo = async (event) => {
        event.preventDefault()

        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/asignar_ciclo', {
            ciclo: selecciones.cicloSeleccionado.id_ciclo,
            curso: selecciones.cursoSeleccionado3.id_curso
        })
            .then(response => {
                if (response.status === 200) {
                    toast.success("Se asigno el curso al ciclo seleccionado! " + response.data.asignado, { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                    setSelecciones({
                        ...selecciones,
                        cursoSeleccionado3: undefined,
                        cicloSeleccionado: undefined
                    });
                } else {
                    toast.error("No se ha podido registrar curso al ciclo", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    return (
        <div style={{ width: "80%", marginLeft: "10%" }}>
            <Accordion className="accordion-custom" activeIndex={2}>
                <AccordionTab header={<React.Fragment><span>Curso</span></React.Fragment>}>
                    <Box display="flex" justifyContent="center" >
                        <Form onSubmit={handleClickCatedratico} style={{ width: "90%" }}>
                            <FormGroup>
                                <Dropdown
                                    value={selecciones.cursoSeleccionado1}
                                    options={cursos}
                                    onChange={onChangeCurso1}
                                    optionLabel="nombre"
                                    filter
                                    showClear
                                    filterBy="nombre"
                                    placeholder="Seleccione un curso"
                                    style={{ width: "100%" }}
                                    required
                                />
                                <Dropdown
                                    value={selecciones.catedraticoSeleccionado}
                                    options={catedraticos}
                                    onChange={onChangeCatedratico}
                                    optionLabel="nombre"
                                    filter
                                    showClear
                                    filterBy="nombre"
                                    placeholder="Seleccione un catedratico"
                                    style={{ width: "100%" }}
                                    required
                                />
                                <Button
                                    variant="contained"
                                    size="large"
                                    style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '100%', justifyContent: 'center', alignItems: 'center' }}
                                >
                                    Registrar
                                </Button>
                            </FormGroup>
                        </Form>
                    </Box>
                </AccordionTab>
                <AccordionTab header={<React.Fragment><span>Actividad</span></React.Fragment>}>
                    <Box display="flex" justifyContent="center" >
                        <Form onSubmit={handleClickActividad} style={{ width: "90%" }}>
                            <FormGroup>
                                <Dropdown
                                    value={selecciones.actividadSeleccionada}
                                    options={actividades}
                                    onChange={onChangeActividad}
                                    optionLabel="nombre"
                                    filter
                                    showClear
                                    filterBy="nombre"
                                    placeholder="Seleccione una actividad"
                                    style={{ width: "100%" }}
                                    required
                                />
                                <Dropdown
                                    value={selecciones.cursoSeleccionado2}
                                    options={cursos}
                                    onChange={onChangeCurso2}
                                    optionLabel="nombre"
                                    filter
                                    showClear
                                    filterBy="nombre"
                                    placeholder="Seleccione un curso"
                                    style={{ width: "100%" }}
                                    required
                                />
                                <Button
                                    variant="contained"
                                    size="large"
                                    style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '100%', justifyContent: 'center', alignItems: 'center' }}
                                >
                                    Registrar
                                </Button>
                            </FormGroup>
                        </Form>
                    </Box>
                </AccordionTab>
                <AccordionTab header={<React.Fragment><span>Ciclo</span></React.Fragment>}>
                    <Box display="flex" justifyContent="center" >
                        <Form onSubmit={handleClickCiclo} style={{ width: "90%" }}>
                            <FormGroup>
                                <Dropdown
                                    value={selecciones.cicloSeleccionado}
                                    options={ciclos}
                                    onChange={onChangeCiclo}
                                    optionLabel="nombre"
                                    filter
                                    showClear
                                    filterBy="nombre"
                                    placeholder="Seleccione un ciclo"
                                    style={{ width: "100%" }}
                                    required
                                />
                                <Dropdown
                                    value={selecciones.cursoSeleccionado3}
                                    options={cursos}
                                    onChange={onChangeCurso3}
                                    optionLabel="nombre"
                                    filter
                                    showClear
                                    filterBy="nombre"
                                    placeholder="Seleccione un curso"
                                    style={{ width: "100%" }}
                                    required
                                />
                                <Button
                                    variant="contained"
                                    size="large"
                                    style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '100%', justifyContent: 'center', alignItems: 'center' }}
                                >
                                    Registrar
                                </Button>
                            </FormGroup>
                        </Form>
                    </Box>
                </AccordionTab>
            </Accordion>
        </div>
    );
}

export default withRouter(Asignacion);
