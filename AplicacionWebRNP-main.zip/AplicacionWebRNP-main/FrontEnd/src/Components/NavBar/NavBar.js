import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';
import { withRouter } from 'react-router-dom';
import Links from '../Props/Links';
import Inicio from '../Inicio/Inicio';
import Box from '@material-ui/core/Box';
import { FormGroup } from '@material-ui/core';
import { List } from "@rmwc/list";
import { ToastContainer } from 'react-toastify';

import '@rmwc/typography/styles';
import '@rmwc/list/styles';
import '@material/list/dist/mdc.list.css';
import '@rmwc/drawer/styles';
import '@material/drawer/dist/mdc.drawer.css';
import '@material/ripple/dist/mdc.ripple.css';
import '@rmwc/top-app-bar/styles'
import '@material/top-app-bar/dist/mdc.top-app-bar.css';
import '@material/icon-button/dist/mdc.icon-button.css';
import '@rmwc/icon/icon.css';
import '@rmwc/theme/styles';
import '@material/theme/dist/mdc.theme.css';
import '@rmwc/theme/theme.css';

import {
    TopAppBar,
    TopAppBarRow,
    TopAppBarSection,
    TopAppBarNavigationIcon,
    TopAppBarTitle,
    TopAppBarFixedAdjust
} from "@rmwc/top-app-bar";

import {
    Drawer,
    DrawerContent,
    DrawerHeader,
    DrawerTitle,
    DrawerAppContent
} from "@rmwc/drawer";

import {
    ThemeProvider
} from "@rmwc/theme";
import Catedratico from '../Catedratico/Catedratico';
import Actividad from '../Actividad/Actividad';
import Curso from '../Curso/Curso';
import Asignacion from '../Asignacion/Asignacion';
import Ciclo from '../Ciclo/Ciclo';
import Reporte from '../Reportes/Reporte';

const NavBar = ({ history }) => {
    const [open, setOpen] = useState(false);
    const drawerOpen = () => {
        setOpen(true)
    }

    const espera = () => {
        setTimeout(() => {
        }, 4000);
    }

    return (
        <ThemeProvider
            options={{
                primary: '#5C8E04',
                secondary: 'black',
                onPrimary: '#000',
                textPrimaryOnBackground: 'black'
            }}
        >
            <ToastContainer />

            <Router history={history}>
                <Drawer modal open={open} onClose={() => setOpen(false)}>
                    {espera()}
                    <DrawerHeader>
                    </DrawerHeader>
                    <br />
                    <DrawerContent>
                        <List>
                            <FormGroup>
                                <Box><Links path='/Catedratico' texto='Catedratico' /></Box>
                                <Box><Links path='/Curso' texto='Curso' /></Box>
                                <Box><Links path='/Ciclo' texto='Ciclo' /></Box>
                                <Box><Links path='/Actividad' texto='Actividad' /></Box>
                                <Box><Links path='/Asignacion' texto='Asignacion' /></Box>
                                <Box><Links path='/Reportes' texto='Reportes' /></Box>
                            </FormGroup>
                        </List>
                    </DrawerContent>
                </Drawer>

                <DrawerAppContent>
                    <TopAppBar fixed short>
                        {espera()}
                        <TopAppBarRow  >
                            <TopAppBarSection>
                                <TopAppBarNavigationIcon icon="menu" onClick={() => drawerOpen(!open)} />
                                <TopAppBarTitle></TopAppBarTitle>
                            </TopAppBarSection>
                        </TopAppBarRow>
                    </TopAppBar>
                    <TopAppBarFixedAdjust />
                    <div style={{ height: '100rem' }}>
                        <Switch>
                        <Route exact path='/' component={Inicio} ></Route>
                        <Route exact path='/Catedratico' component={Catedratico} ></Route>
                        <Route exact path='/Curso' component={Curso} ></Route>
                        <Route exact path='/Ciclo' component={Ciclo} ></Route>
                        <Route exact path='/Actividad' component={Actividad} ></Route>
                        <Route exact path='/Asignacion' component={Asignacion} ></Route>
                        <Route exact path='/Reportes' component={Reporte} ></Route>
                        {espera()}
                            <Redirect from="*" to="/" />
                        </Switch>
                    </div>
                </DrawerAppContent>
            </Router>
        </ThemeProvider>
    )
}

export default withRouter(NavBar);