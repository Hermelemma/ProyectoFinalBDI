const serversAddr = {
  backend: {
    host: "localhost",
    port: "9090",
  },
};

module.exports = serversAddr;
