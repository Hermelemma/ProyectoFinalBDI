import React, { Component } from 'react';
import { withRouter, Link } from 'react-router-dom';
import Box from '@material-ui/core/Box';
import axios from 'axios';
import serversAddr from '../serversAddr';
import { toast } from 'react-toastify';
import DatePicker from "react-datepicker";
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Dropdown } from 'primereact/dropdown';
import { Form, FormGroup } from 'reactstrap';
import { Button } from "@rmwc/button";
import 'date-fns';
import '@rmwc/typography/styles';
import 'react-toastify/dist/ReactToastify.css';
import CanvasJSReact from '../Canvas/canvasjs.react';
import { data } from 'jquery';
var CanvasJS = CanvasJSReact.CanvasJS;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;

class Reporte extends Component {
    constructor(props) {
        super(props)
        this.chart1 = React.createRef();
        this.chart2 = React.createRef();
        this.state = {
            refresh: true,
            fecha: new Date(),
            cursos: [],
            cursoSeleccionado: null,
            grafica1: {
                animationEnabled: true,
                exportEnabled: true,
                theme: "light2", //"light1", "dark1", "dark2"
                title: {
                    text: "Proyectado"
                },
                axisY: {
                    includeZero: true,
                    title: "Dia del mes"
                },
                axisX: {
                    title: "Nombre Actividad"
                },
                data: [{
                    type: "column",
				indexLabel: "{y}",		
				indexLabelFontColor: "white",
				dataPoints: [
				]
                }]
            },
            grafica2: {
                animationEnabled: true,
                exportEnabled: true,
                theme: "light2", //"light1", "dark1", "dark2"
                title: {
                    text: "Ejecutado"
                },
                axisY: {
                    includeZero: true
                },
                data: [{
                    type: "column", //change type to bar, line, area, pie, etc
                    //indexLabel: "{y}", //Shows y value on all Data Points
                    indexLabelFontColor: "#5A5757",
                    indexLabelPlacement: "outside",
                    dataPoints: []
                }]
            },
        }
    }

    obtenerCursos = async () => {
        await axios.get('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_cursos')
            .then(response => {
                let cursos = response.data.cursos;
                if (response.status === 200) {
                    this.setState({
                        cursos
                    });
                } else {
                    toast.error("No se puedieron obtener los cursos registrados.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    componentDidMount() {
        this.setState({
            refresh: false
        });

        this.obtenerCursos();
    }

    setDataProyectada = async () => {
        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_ejecutadas', {
            curso: this.state.cursoSeleccionado.id_curso,
            mes: this.state.fecha.getMonth()
        })
            .then(response => {
                if (response.status === 200) {
                    this.state.grafica1.data[0].dataPoints = response.data.map(e => ({ label: e.nombre, y: new Date(e.fecha).getDay() }))
                    this.chart1.render();
                } else {
                    toast.error("Error al generar la gráfica de actividades ejecutadas.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    setDataEjecutada = async () => {
        await axios.post('http://' + serversAddr.backend.host + ':' + serversAddr.backend.port + '/obtener_proyectadas', {
            mes: this.state.fecha.getMonth(),
            anio: this.state.fecha.getFullYear(),
            curso: this.state.cursoSeleccionado.id_curso
        })
            .then(response => {
                if (response.status === 200) {
                    this.state.grafica2.data[0].dataPoints = response.data.map(e => ({ label: e.nombre, y: new Date(e.fecha).getDay() }))
                    this.chart2.render();
                } else {
                    toast.error("Error al generar la gráfica de actividades ejecutadas.", { position: toast.POSITION.TOP_RIGHT, autoClose: 5000, theme: "dark" });
                }
            })
    }

    handleClickGraficar = async (e) => {
        e.preventDefault();
        this.setDataEjecutada();
        this.setDataProyectada();
    }

    onChangeCurso = (e) => {
        this.setState({
            cursoSeleccionado: e.value
        });
    }

    render() {

        return (
            <div style={{ width: "80%", marginLeft: "10%" }}>
                <Form onSubmit={this.handleClickGraficar}>
                    <FormGroup>
                        <DatePicker
                            selected={this.state.fecha}
                            onChange={(date) =>
                                this.setState({
                                    fecha: date
                                })
                            }
                            dateFormat="MM/yyyy"
                            showMonthYearPicker
                            showFullMonthYearPicker
                            required
                        />
                        <Dropdown
                            value={this.state.cursoSeleccionado}
                            options={this.state.cursos}
                            onChange={this.onChangeCurso}
                            optionLabel="nombre"
                            filter
                            showClear
                            filterBy="nombre"
                            placeholder="Seleccione un curso"
                            style={{ width: "100%" }}
                            required
                        />
                        <Button
                            variant="contained"
                            size="large"
                            style={{ color: '#FFFFFF', backgroundColor: '#0B78F4', width: '100%', justifyContent: 'center', alignItems: 'center' }}
                        >
                            Ver graficas
                        </Button>
                    </FormGroup>
                </Form>
                <Accordion className="accordion-custom" activeIndex={0}>
                    <AccordionTab header={<React.Fragment><span>Proyectado</span></React.Fragment>}>
                        <Box display="flex" justifyContent="center" >
                            <CanvasJSChart options={this.state.grafica1} onRef={ref => this.chart1 = ref} />
                        </Box>
                    </AccordionTab>
                    <AccordionTab header={<React.Fragment><span>Ejecutado</span></React.Fragment>}>
                        <Box display="flex" justifyContent="center" >
                            <CanvasJSChart options={this.state.grafica2} onRef={ref => this.chart2 = ref} />
                        </Box>
                    </AccordionTab>
                </Accordion>
            </div>
        );
    }
}

export default withRouter(Reporte);
