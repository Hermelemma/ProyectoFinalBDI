import React, { useEffect }  from 'react';
import './App.css';
import NavBar from './Components/NavBar/NavBar';
import { BrowserRouter as Router, Switch, Route, Link, Redirect } from 'react-router-dom';


function App() {
  return(
    <Router>
      <NavBar/>
    </Router>
  );
}

export default App;
