#!/bin/bash
echo
echo ┌────────────────────────────────────╖
echo │ executing database creation script ║
echo ╘════════════════════════════════════╝
echo

set -e

psql -v ON_ERROR_STOP=1 -U "$POSTGRES_USER" -d "$POSTGRES_DB" <<-EOSQL

-- database creation
CREATE DATABASE proyecto
WITH
OWNER = postgres
ENCODING = 'UTF8'
CONNECTION LIMIT = -1;

-- connection to the database
\c proyecto;

-- tables creation

-- catalog tables
CREATE TABLE Curso (
id_curso SERIAL PRIMARY KEY,
nombre varchar
);

CREATE TABLE Catedratico (
id_catedratico SERIAL PRIMARY KEY,
nombre varchar NOT NULL
);

CREATE TABLE Actividad (
id_actividad SERIAL PRIMARY KEY,
nombre varchar NOT NULL,
fecha date NOT NULL
);

CREATE TABLE Ciclo (
id_ciclo SERIAL PRIMARY KEY,
nombre varchar NOT NULL
);

CREATE TABLE Tema (
id_tema SERIAL PRIMARY KEY,
nombre varchar NOT NULL,
temaPadre int
);

CREATE TABLE Actividad_Curso (
id_actividad int,
id_curso int,
PRIMARY KEY (id_actividad, id_curso)
);

CREATE TABLE Curso_Catedratico (
id_curso int,
id_catedratico int,
PRIMARY KEY (id_curso, id_catedratico)
);

CREATE TABLE Curso_Ciclo (
id_curso int,
id_ciclo int,
PRIMARY KEY (id_curso, id_ciclo)
);

CREATE TABLE Actividad_Tema (
id_actividad int,
id_tema int,
PRIMARY KEY (id_actividad, id_tema)
);

ALTER TABLE Actividad_Curso ADD FOREIGN KEY (id_actividad) REFERENCES Actividad (id_actividad);

ALTER TABLE Actividad_Curso ADD FOREIGN KEY (id_curso) REFERENCES Curso (id_curso);

ALTER TABLE Curso_Catedratico ADD FOREIGN KEY (id_catedratico) REFERENCES Catedratico (id_catedratico);

ALTER TABLE Curso_Catedratico ADD FOREIGN KEY (id_curso) REFERENCES Curso (id_curso);

ALTER TABLE Curso_Ciclo ADD FOREIGN KEY (id_curso) REFERENCES Curso (id_curso);

ALTER TABLE Curso_Ciclo ADD FOREIGN KEY (id_ciclo) REFERENCES Ciclo (id_ciclo);

ALTER TABLE Actividad_Tema ADD FOREIGN KEY (id_actividad) REFERENCES Actividad (id_actividad);

ALTER TABLE Actividad_Tema ADD FOREIGN KEY (id_tema) REFERENCES Tema (id_tema);

ALTER TABLE Tema ADD FOREIGN KEY (temaPadre) REFERENCES Tema (id_tema);
EOSQL
